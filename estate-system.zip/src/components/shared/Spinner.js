import React from "react";

const Spinner = () => {
  return (
    <div className="spinner-border text-light spinner-border-sm me-2"></div>
  );
};

export default Spinner;
