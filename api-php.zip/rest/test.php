<?php

//header("Content-Type:application/json");

//$url = "https://api.wallex.ir/v1/markets" ;
//
//$client = curl_init();
//curl_setopt($client, CURLOPT_URL,$url);
//curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
//
//$response = curl_exec($client);
//curl_close($client);
//
//$result = json_decode($response);
$data = json_decode(file_get_contents('php://input'), true);
print_r($data);

echo "<br>";




