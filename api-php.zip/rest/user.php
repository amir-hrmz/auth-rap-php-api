<?php
include '../vendor/autoload.php';
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
require_once 'db.php';
header("Content-Type:application/json");
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Method:POST');




$data = json_decode(file_get_contents("php://input"));

$secret_key = "teasdasdad5435st";
$jwt = isset($data->jwt) ? $data->jwt : "";

if ($jwt) {

    try {
        $decoded = JWT::decode($jwt, $secret_key, new Key($secret_key, 'HS256'));
        http_response_code(200);

    } catch (Exception $e) {
        http_response_code(401);

        // show error message
        echo json_encode(array(
            "message" => "Access d.",
            "error" => $e->getMessage()
        ));
    }


} else {
    header('HTTP/1.0 401 Unauthorized');
    echo json_encode(array(
        "message" => "شما دسترسی به این صفحه ندارید"
    ));

    die();
}


$res = mysqli_query($db, "select id,business_license,estate_name,national_code,password , image from users");


if (mysqli_num_rows($res) > 0) {

    while ($row = mysqli_fetch_assoc($res)) {
        $data1[] = $row;
    }
    $response = [];
    $response['user'] = $data1;
    echo json_encode($response, JSON_PRETTY_PRINT);
}

