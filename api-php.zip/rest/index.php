<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form action="jwt-create.php" method="post">
    <label for="name">نام کاربری</label>
    <input type="text" name="name" id="name">
    <input type="submit" value="درخواست api">

</form>
<h1>ورود</h1>
<form action="login.php" method="post">
    <label for="estate_name">نام کاربری</label>
    <input type="text" name="business_license" id="business_license">
    <input type="password" name="password" id="password">
    <input type="submit" value="ورود">

</form>
<h1>ثبت نام</h1>
<form action="register.php" method="post">
    <label for="business_license">کد ثبت</label>
    <input type="text" placeholder="کد ثبت" name="business_license" id="business_license">
    <input type="text" placeholder="نام املاکی" name="estate_name" id="estate_name ">
    <input type="text" placeholder="کد ملی" name="national_code" id="national_code">
    <input type="password" placeholder="رمز عبور" name="password" id="password">
    <input type="submit" value="ثبت نام">

</form>
</body>
</html>

