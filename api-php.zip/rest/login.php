<?php
header("Content-Type:application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");


//here we create jwt for accessing others to our api
include '../vendor/autoload.php';
//use php-jwt namespace
use \Firebase\JWT\JWT;
require 'db.php';

$business_license = $_POST['business_license'];
$password=md5($_POST['password']);

$checkUser="SELECT * FROM users WHERE business_license='$business_license'";

$result=mysqli_query($db,$checkUser);



if(mysqli_num_rows($result)>0){

$checkUserquery="SELECT id, estate_name, national_code FROM users WHERE business_license='$business_license' and password='$password'";
$resultant=mysqli_query($db,$checkUserquery);

if(mysqli_num_rows($resultant)>0){

while($row=$resultant->fetch_assoc())

$response['user']=$row;
$response['response']="200";
$response['message']="لاگین موفقیت آمیز بود";
}
else{
$response['user']=(object)[];
$response['response']="400";
$response['message']="اطلاعات ورود اشتباه است";
}


}
else{

$response['user']=(object)[];
$response['response']="400";
$response['message']="این نام کاربری وجود ندارد";


}

echo json_encode($response);

?>