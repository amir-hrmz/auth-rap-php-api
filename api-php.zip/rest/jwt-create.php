<?php
header("Content-Type:application/json");
//here we create jwt for accessing others to our api
include '../vendor/autoload.php';
//use php-jwt namespace
use \Firebase\JWT\JWT;

$user_name = $_POST['name'];
$secret_key = "teasdasdad5435st";

$payload = array(
//     "iss" => "http://example.org",
//     "iat" => time(),
//     "nbf" => time() + 10,
//     "exp" => time() + 3600,
    $data = array(
        'name' => $user_name
    )
);


$jwt = JWT::encode($payload, $secret_key,'HS256');

//echo $user_name."توکن شما با موفقیت ساخته شد" . "</br>";
//echo "<pre><samp>" . $jwt . "</samp></pre>";
//echo $secret_key;
$api=array(
    'username' => $user_name,
    'token' => $jwt
);
echo json_encode($api);

