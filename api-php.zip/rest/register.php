<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
header("Content-Type: text/html; charset=utf-8");
header("Content-Type:application/json");

//here we create jwt for accessing others to our api
include '../vendor/autoload.php';
//use php-jwt namespace
use \Firebase\JWT\JWT;

require_once 'db.php';
$url = "http://uni.papion-acc.ir/api-php/rest/register.php";

// $client = curl_init($url);
// curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
// curl_setopt($client, CURLOPT_URL,$url);
// $response = curl_exec($client);
// curl_close($client);
// // var_dump($response);
// $data = json_decode($response ,true);
// var_dump($data);
// die();
$json = file_get_contents($url);
$data = json_decode($json);
var_dump($data);
$business_license=$data->license;
$estate_name=$data->name;
$national_code=$data->nationalCode;
$password=$data->password;



//$business_license = $_POST['business_license'];
//$estate_name = $_POST['estate_name'];
//$national_code = $_POST['national_code'];
//$password = md5($_POST['password']);
//echo $business_license;
//echo $estate_name;
//echo $national_code;
//echo $password;
// die();


// var_dump($business_license);
// var_dump($estate_name);
// var_dump($national_code);
// var_dump($password);

if (isset($business_license) && isset($estate_name) && isset($national_code)) {
    $checkUser = "SELECT * from users WHERE business_license='$business_license'";
    $checkQuery = mysqli_query($db, $checkUser);


    if (mysqli_num_rows($checkQuery) > 0) {
        $response['code'] = "402";
        $response['message'] = "این کد ثبت وجود دارد";
        echo json_encode($response);
    } else {
        $insertQuery = "INSERT INTO users(business_license,estate_name,national_code,password) VALUES('$business_license',
    '$estate_name','$national_code','$password')";
        $result = mysqli_query($db, $insertQuery);

        if ($result) {
            $user_name = $_POST['business_license'];
            $secret_key = "teasdasdad5435st";

            $payload = array(
//     "iss" => "http://example.org",
//     "iat" => time(),
//     "nbf" => time() + 10,
//     "exp" => time() + 3600,
                $data = array(
                    'business_license' => $user_name
                )
            );


            $jwt = JWT::encode($payload, $secret_key, 'HS256');

            $response['business_license'] = $user_name;
            $response['token'] = $jwt;

            $response['code'] = "200";
            $response['message'] = "ثبت نام با موفقیت انجام شد!";
            echo json_encode($response);
        } else {
            $response['code'] = "400";
            $response['message'] = "ثبت نام با خطا مواجه شد!";
            echo json_encode($response);
        }

    }
}

